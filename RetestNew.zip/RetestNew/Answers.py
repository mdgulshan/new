
import pandas as pd

unique_dept=[]
Sum=0
df=pd.read_csv("emp1.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()
y=df["salary"].tolist()
Sum=Sum+sum(y)

#print(unique_dept)
female_emp_count1=c.count("f")
male_emp_count1=c.count("m")

df=pd.read_csv("emp4.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count2=c.count("f")
male_emp_count2=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp5.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count3=c.count("f")
male_emp_count4=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp6.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count5=c.count("f")
male_emp_count5=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp8.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count6=c.count("f")
male_emp_count6=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)





df=pd.read_csv("stud1.dat")
c=df["gen"].tolist()

female_stud1_count1=c.count("f")
male_stud1_count1=c.count("m")

df=pd.read_csv("stud7.dat")
c=df["gen"].tolist()

female_stud7_count2=c.count("f")
male_stud7_count2=c.count("m")

df=pd.read_csv("stud4.dat")
c=df["gen"].tolist()

female_stud4_count3=c.count("f")
male_stud4_count3=c.count("m")

df=pd.read_csv("stud2.dat")
c=df["gen"].tolist()

female_stud2_count4=c.count("f")
male_stud2_count4=c.count("m")

print("*"*40)

print("Total numbers males students and employee are =",male_stud7_count2+
      male_stud1_count1+
      male_emp_count5+
      male_emp_count6+
      male_emp_count4+
      male_emp_count2+
      male_emp_count1+
    male_stud4_count3+
      male_stud2_count4)
print("Total numbers females students and employe are",female_stud2_count4+
      female_stud4_count3+
      female_stud1_count1+
      female_stud7_count2+
      female_emp_count6+
      female_emp_count5+
      female_emp_count3+
      female_emp_count1+
      female_emp_count2)

print("*"*40)



print(set(unique_dept))

print("*"*40)

print("Sum of all salaries are =",Sum)

print("*"*40)


#---------------------------------------------------------------------------#
import os
root_dir = r'C:\Users\gm67149\Desktop\Questionare\Questionare\Root'
file_list = []
for sub_dir, dirs, files in os.walk(root_dir):
    for file in files:
        file_list.append(os.path.join(sub_dir, file))


fruit_list = []

for file_name in file_list:
    with open(file_name,'r') as handle:
        file_data = handle.read().split('\n')[1:-1]
        if 'Fruit' in file_name:
            for line in file_data:
                fruit_list.append(line.split(','))

total_quantity = 0
unique_fruits = set()
quantity_list = [0, 0, 0] #Apple, orange, grapes
apples_quantity = 0
oranges_quantity = 0
grapes_quantity = 0

for fruit in fruit_list:
    #print(fruit[1].lower())
    total_quantity += int(fruit[3])
    unique_fruits.add(fruit[1])
    if fruit[1].lower() == 'apple':
        quantity_list[0] += int(fruit[3])
    elif fruit[1].lower() == 'orange':
        quantity_list[1] += int(fruit[3])
    elif fruit[1].lower() == 'grapes':
        quantity_list[2] += int(fruit[3])

print(f'Quantity(in Kgs) of Apples, Oranges and Grapes: {quantity_list}')
print("*"*40)
print(f'Unique list of fruits: {unique_fruits}')
print("*"*40)

print(f'Total quantity of fruits(in Kgs): {total_quantity}')
print("*"*40)

#---------------------------------------------------------------------------#
import os
root_dir = r'C:\Users\gm67149\Desktop\Questionare\Questionare\Root'
file_list = []
for sub_dir, dirs, files in os.walk(root_dir):
    for file in files:
        file_list.append(os.path.join(sub_dir, file))

emp_list = []
stud_list = []


for file_name in file_list:
    with open(file_name,'r') as handle:
        file_data = handle.read().split('\n')[1:-1]
        if 'emp' in file_name:
            for line in file_data:
                emp_list.append(line.split(','))
        if 'stud' in file_name:
            for line in file_data:
                stud_list.append(line.split(','))


count_dat_files = len(file_list)
total_emp_count = len(emp_list)




count_male_stud = 0
count_female_stud = 0
total_stud_count = len(stud_list)
stud_pass_count = 0
stud_fail_count = 0
for student in stud_list:
    if student[2]=='m':
        count_male_stud += 1
    else:
        count_female_stud += 1
    if int(student[4][:-1])<35:
        stud_fail_count += 1
    else:
        stud_pass_count += 1


print(f'Count of passed students: {stud_pass_count}')
print(f'Count of failed students: {stud_fail_count}')
print("*"*40)

print(f'Total count of employees: {total_emp_count}')
print(f'Total count of students: {total_stud_count}')
print("*"*40)

#---------------------------------------------------------------------------#
import glob
path = r"C:\Users\gm67149\PycharmProjects\zensar\retest\ans1"

all_files = glob.glob(path+"/*.dat")
count = 0
for file in all_files:
    count += 1
print(f"total .dat files : {count}")
print("*"*40)
